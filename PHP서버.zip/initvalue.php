<?php
$con=mysqli_connect("localhost","HJ","ss931219@","testdb");
 
if (mysqli_connect_errno($con))
{
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($con,"SELECT * FROM s_values");
 
$row = mysqli_fetch_array($result);

$result3 = mysqli_query($con,"DELETE FROM s_values2");

while($row[0]!=NULL)
{

	$data1 = $row[0];
	$data2 = $row[1];
	$data3 = $row[2];
	$data4 = $row[3];
	$data5 = $row[4];
	$data6 = $row[5];
	$data7 = $row[6];
	$data8 = $row[7];
	$data9 = $row[8];
	
	if($data1){
	echo $data1," ",$data2," ", $data3," ", $data4," ", $data5," ", $data6," ", $data7," ",$data8," ",$data9," ";
	}
	
	$result2 = mysqli_query($con,"INSERT INTO s_values2(x,y,z,x_,y_,z_,j,b) VALUES($data2, $data3, $data4, $data5, $data6, $data7, $data8, $data9)");

	$row = mysqli_fetch_array($result);
}
$result3 = mysqli_query($con,"DELETE FROM s_values");

mysqli_close($con);
?>